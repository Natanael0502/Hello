<%@ WebHandler Language="C#" Class="ApiHandler" %>

using System;
using System.Web;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web.Script.Serialization;

public class ApiHandler : IHttpHandler
{
    public void ProcessRequest(HttpContext context)
    {
        // Le decimos al navegador que esto es una API que devuelve JSON
        context.Response.ContentType = "application/json";
        context.Response.ContentEncoding = System.Text.Encoding.UTF8;

        string connectionString = "Server=RXGSWSO01;Database=ServerWindows;User Id=sa;Password=N@7an2026#;";
        
        var dashboardData = new Dictionary<string, object>();
        var osLabels = new List<string>();
        var osData = new List<int>();

        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // 1. KPIs Generales
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Servidores_Core", conn))
                    dashboardData["TotalServidores"] = cmd.ExecuteScalar();

                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Servidores_Core WHERE EstadoConexion LIKE '%Offline%'", conn))
                    dashboardData["Offline"] = cmd.ExecuteScalar();

                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Servidores_Seguridad_Estado WHERE ReinicioPendiente = 'Sí'", conn))
                    dashboardData["Reinicios"] = cmd.ExecuteScalar();

                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Servidores_Seguridad_Estado WHERE Antivirus LIKE '%No detectado%'", conn))
                    dashboardData["SinAntivirus"] = cmd.ExecuteScalar();

                // 2. Datos para la Gráfica (Sistemas Operativos)
                string queryOS = "SELECT SistemaOperativo, COUNT(*) as Total FROM Servidores_Core GROUP BY SistemaOperativo ORDER BY Total DESC";
                using (SqlCommand cmd = new SqlCommand(queryOS, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string osName = reader["SistemaOperativo"].ToString().Replace("Microsoft ", "").Replace("Datacenter", "").Trim();
                        osLabels.Add(string.IsNullOrEmpty(osName) ? "Desconocido" : osName);
                        osData.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

// 3. Datos para la Tabla de Servidores
var serverList = new List<Dictionary<string, object>>();

// Consulta actualizada con JOIN para traer la IP desde Servidores_Red
string queryTable = @"
    SELECT 
        c.Hostname, 
        r.Direccion_IP, 
        c.SistemaOperativo, 
        c.EstadoConexion 
    FROM Servidores_Core c
    LEFT JOIN Servidores_Red r ON c.Hostname = r.Hostname";

using (SqlCommand cmd = new SqlCommand(queryTable, conn))
using (SqlDataReader reader = cmd.ExecuteReader())
{
    while (reader.Read())
    {
        var server = new Dictionary<string, object>();
        server["Nombre"] = reader["Hostname"].ToString();
        
        // Validación por si el servidor no tiene registro en Servidores_Red
        server["IP"] = reader["Direccion_IP"] != DBNull.Value ? reader["Direccion_IP"].ToString() : "Sin IP";
        
        server["OS"] = reader["SistemaOperativo"].ToString();
        server["Estado"] = reader["EstadoConexion"].ToString();
        
        serverList.Add(server);
    }
}

                dashboardData["TableData"] = serverList;
                dashboardData["ChartLabels"] = osLabels;
                dashboardData["ChartData"] = osData;
                dashboardData["Status"] = "OK";
            }
        }
        catch (Exception ex)
        {
            dashboardData["Status"] = "Error";
            dashboardData["Message"] = ex.Message;
        }

        // Convertir a JSON y enviar
        JavaScriptSerializer js = new JavaScriptSerializer();
        context.Response.Write(js.Serialize(dashboardData));
    }

    public bool IsReusable { get { return false; } }
}
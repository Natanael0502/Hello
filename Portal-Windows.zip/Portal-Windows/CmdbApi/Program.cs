using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

// Configurar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();
app.UseCors("AllowAll");

// ==========================================
// ENDPOINT 1: DASHBOARD GENERAL (Filtrado por último registro)
// ==========================================
app.MapGet("/dashboard", (IConfiguration config) =>
{
    var dashboardData = new Dictionary<string, object>();
    var osLabels = new List<string>();
    var osData = new List<int>();
    var serverList = new List<Dictionary<string, object>>();

    string connectionString = config.GetConnectionString("DefaultConnection");

    try
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            string latestCoreCTE = @"
                SELECT c.* 
                FROM Servidores_Core c
                INNER JOIN (
                    SELECT Hostname, MAX(FechaConsulta) as MaxFecha
                    FROM Servidores_Core
                    GROUP BY Hostname
                ) latest ON c.Hostname = latest.Hostname AND c.FechaConsulta = latest.MaxFecha";

            string queryTotal = $"SELECT COUNT(*) FROM ({latestCoreCTE}) as t";
            using (SqlCommand cmd = new SqlCommand(queryTotal, conn))
                dashboardData["TotalServidores"] = cmd.ExecuteScalar();

            string queryOffline = $"SELECT COUNT(*) FROM ({latestCoreCTE}) as t WHERE EstadoConexion LIKE '%Offline%' OR EstadoConexion = 'Desconectado'";
            using (SqlCommand cmd = new SqlCommand(queryOffline, conn))
                dashboardData["Offline"] = cmd.ExecuteScalar();

            string queryReinicios = $"SELECT COUNT(*) FROM ({latestCoreCTE}) as t WHERE ReinicioPendiente = 'Sí'";
            using (SqlCommand cmd = new SqlCommand(queryReinicios, conn))
                dashboardData["Reinicios"] = cmd.ExecuteScalar();

            string queryNoAV = $@"
                SELECT COUNT(c.Hostname) 
                FROM ({latestCoreCTE}) c 
                LEFT JOIN AgenteAntivirus a ON c.Hostname = a.Hostname 
                WHERE (a.AgenteSentinelone IS NULL OR a.AgenteSentinelone = '') 
                  AND (a.AgenteDeepSecurity IS NULL OR a.AgenteDeepSecurity = '')";
            using (SqlCommand cmd = new SqlCommand(queryNoAV, conn))
                dashboardData["SinAntivirus"] = cmd.ExecuteScalar();

            string queryOS = $"SELECT SistemaOperativo, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY SistemaOperativo ORDER BY Total DESC";
            using (SqlCommand cmd = new SqlCommand(queryOS, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string osName = reader["SistemaOperativo"].ToString().Replace("Microsoft ", "").Replace("Datacenter", "").Trim();
                    osLabels.Add(string.IsNullOrEmpty(osName) ? "Desconocido" : osName);
                    osData.Add(Convert.ToInt32(reader["Total"]));
                }
            }
            dashboardData["ChartLabels"] = osLabels;
            dashboardData["ChartData"] = osData;

            var ramLabels = new List<string>();
            var ramData = new List<int>();
            string queryRAM = $"SELECT RAM_GB, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY RAM_GB ORDER BY RAM_GB";
            using (SqlCommand cmd = new SqlCommand(queryRAM, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    ramLabels.Add(reader["RAM_GB"].ToString() + " GB");
                    ramData.Add(Convert.ToInt32(reader["Total"]));
                }
            }
            dashboardData["ChartRamLabels"] = ramLabels;
            dashboardData["ChartRamData"] = ramData;

            var criticalDisks = new List<Dictionary<string, object>>();
            string queryDisks = @"
                SELECT TOP 5 d.Hostname, d.LetraUnidad, d.PorcentajeUso 
                FROM Servidores_Discos d
                INNER JOIN (
                    SELECT Hostname, LetraUnidad, MAX(FechaConsulta) as MaxFecha
                    FROM Servidores_Discos
                    GROUP BY Hostname, LetraUnidad
                ) latestD ON d.Hostname = latestD.Hostname AND d.LetraUnidad = latestD.LetraUnidad AND d.FechaConsulta = latestD.MaxFecha
                WHERE d.PorcentajeUso >= 90 
                ORDER BY d.PorcentajeUso DESC";

            using (SqlCommand cmd = new SqlCommand(queryDisks, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var disk = new Dictionary<string, object>();
                    disk["Servidor"] = reader["Hostname"].ToString();
                    disk["Unidad"] = reader["LetraUnidad"].ToString();
                    disk["Uso"] = reader["PorcentajeUso"].ToString();
                    criticalDisks.Add(disk);
                }
            }
            dashboardData["DiscosCriticos"] = criticalDisks;

            var envLabels = new List<string>();
            var envData = new List<int>();
            string queryEnv = $"SELECT ISNULL(Ambiente, 'Sin Definir') as Ambiente, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY Ambiente ORDER BY Total DESC";
            using (SqlCommand cmd = new SqlCommand(queryEnv, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    envLabels.Add(reader["Ambiente"].ToString());
                    envData.Add(Convert.ToInt32(reader["Total"]));
                }
            }
            dashboardData["ChartEnvLabels"] = envLabels;
            dashboardData["ChartEnvData"] = envData;

            var roleLabels = new List<string>();
            var roleData = new List<int>();
            string queryRole = $"SELECT ISNULL(Rol, 'Sin Definir') as Rol, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY Rol ORDER BY Total DESC";
            using (SqlCommand cmd = new SqlCommand(queryRole, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    roleLabels.Add(reader["Rol"].ToString());
                    roleData.Add(Convert.ToInt32(reader["Total"]));
                }
            }
            dashboardData["ChartRoleLabels"] = roleLabels;
            dashboardData["ChartRoleData"] = roleData;

            string queryTable = $"SELECT Hostname, IP as Direccion_IP, SistemaOperativo, EstadoConexion FROM ({latestCoreCTE}) as t";
                
            using (SqlCommand cmd = new SqlCommand(queryTable, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var server = new Dictionary<string, object>();
                    server["Nombre"] = reader["Hostname"].ToString();
                    server["IP"] = reader["Direccion_IP"] != DBNull.Value ? reader["Direccion_IP"].ToString() : "Sin IP";
                    server["OS"] = reader["SistemaOperativo"].ToString();
                    server["Estado"] = reader["EstadoConexion"].ToString();
                    serverList.Add(server);
                }
            }

            dashboardData["TableData"] = serverList;
            dashboardData["Status"] = "OK";
        }
        
        return Results.Json(dashboardData);
    }
    catch (Exception ex)
    {
        return Results.Json(new { Status = "Error", Message = ex.Message });
    }
});

// ==========================================
// ENDPOINT 2: DETALLE DE SERVIDOR (MÁQUINA DEL TIEMPO)
// ==========================================
app.MapGet("/api/server", (string host, string? fecha, string? mes, IConfiguration config) => 
{
    var response = new Dictionary<string, object>();
    string connectionString = config.GetConnectionString("DefaultConnection");
    
    try
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            
            string targetDate = fecha;
            string targetMonth = mes;

            if (string.IsNullOrEmpty(targetDate))
            {
                string queryDate = string.IsNullOrEmpty(targetMonth) 
                    ? "SELECT MAX(FechaConsulta) FROM Servidores_Core WHERE LOWER(Hostname) = LOWER(@Host)"
                    : "SELECT MAX(FechaConsulta) FROM Servidores_Core WHERE LOWER(Hostname) = LOWER(@Host) AND CONVERT(VARCHAR(7), FechaConsulta, 120) = @Mes";

                using (SqlCommand cmdDate = new SqlCommand(queryDate, conn))
                {
                    cmdDate.Parameters.AddWithValue("@Host", host);
                    if (!string.IsNullOrEmpty(targetMonth)) cmdDate.Parameters.AddWithValue("@Mes", targetMonth);
                    
                    var res = cmdDate.ExecuteScalar();
                    if (res != DBNull.Value && res != null) 
                        targetDate = Convert.ToDateTime(res).ToString("yyyy-MM-dd");
                    else 
                        targetDate = DateTime.Now.ToString("yyyy-MM-dd");
                }
            }
            
            if (string.IsNullOrEmpty(targetMonth)) {
                targetMonth = targetDate.Length >= 7 ? targetDate.Substring(0, 7) : DateTime.Now.ToString("yyyy-MM"); 
            }
            
            response["FechaSeleccionada"] = targetDate; 
            response["MesSeleccionado"] = targetMonth;
            response["Hostname"] = host;

            // Valores por defecto
            response["RAM_GB"] = "0";
            response["CPU"] = "N/A";
            response["OS"] = "N/A";
            response["Ambiente"] = "N/A";
            response["Rol"] = "N/A";
            response["Fabricante"] = "N/A";
            response["Modelo"] = "N/A";
            response["Dominio"] = "N/A";
            response["Uptime"] = "0";
            response["UltimoParche"] = "N/A";
            response["FechaParche"] = "N/A";
            response["Hardening"] = "N/A";
            response["AgenteSeguridad"] = "N/A";
            response["AgenteMonitoreo"] = "N/A";

            // 2. CONSULTA CORE
            string queryCore = @"
                SELECT c.*, 
                       p.ParcheKB, p.FechaInstalacion as FechaParche,
                       h.PlantillaAplicada,
                       a.AgenteSentinelone, a.VersionSentinelone, a.AgenteDeepSecurity, a.VersionDeepSecurity,
                       m.AgenteMonitoreo as NombreMonitoreo, m.EstadoMonitoreo
                FROM Servidores_Core c
                LEFT JOIN (
                    SELECT Hostname, ParcheKB, FechaInstalacion, 
                           ROW_NUMBER() OVER(PARTITION BY Hostname ORDER BY FechaInstalacion DESC) as rn
                    FROM Parches 
                    WHERE CAST(FechaConsulta AS DATE) = @Fecha
                ) p ON LOWER(c.Hostname) = LOWER(p.Hostname) AND p.rn = 1
                LEFT JOIN Servidores_Hardening h ON LOWER(c.Hostname) = LOWER(h.Hostname) AND CAST(h.FechaConsulta AS DATE) = @Fecha
                LEFT JOIN AgenteAntivirus a ON LOWER(c.Hostname) = LOWER(a.Hostname) AND CAST(a.FechaConsulta AS DATE) = @Fecha
                LEFT JOIN AgenteMonitoreo m ON LOWER(c.Hostname) = LOWER(m.Hostname) AND CAST(m.FechaConsulta AS DATE) = @Fecha
                WHERE LOWER(c.Hostname) = LOWER(@Host) AND CAST(c.FechaConsulta AS DATE) = @Fecha";

            using (SqlCommand cmd = new SqlCommand(queryCore, conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    if (reader.Read()) {
                        response["Hostname"] = reader["Hostname"]?.ToString() ?? host;
                        response["RAM_GB"] = reader["RAM_GB"]?.ToString() ?? "0";
                        response["CPU"] = reader["CPU"]?.ToString() ?? "N/A";
                        response["OS"] = reader["SistemaOperativo"]?.ToString() ?? "N/A";
                        response["Ambiente"] = reader["Ambiente"] != DBNull.Value ? reader["Ambiente"].ToString() : "-";
                        response["Rol"] = reader["Rol"] != DBNull.Value ? reader["Rol"].ToString() : "-";
                        response["Fabricante"] = reader["Fabricante"] != DBNull.Value ? reader["Fabricante"].ToString() : "-";
                        response["Modelo"] = reader["Modelo"] != DBNull.Value ? reader["Modelo"].ToString() : "-";
                        response["Dominio"] = reader["Dominio"] != DBNull.Value ? reader["Dominio"].ToString() : "-";
                        
                        // Lectura de Uptime_Dias de tu tabla Servidores_Core
                        try { response["Uptime"] = reader["Uptime_Dias"] != DBNull.Value ? reader["Uptime_Dias"].ToString() : "0"; } catch { response["Uptime"] = "0"; }
                        
                        response["UltimoParche"] = reader["ParcheKB"] != DBNull.Value ? reader["ParcheKB"].ToString() : "Sin parches";
                        if (reader["FechaParche"] != DBNull.Value && DateTime.TryParse(reader["FechaParche"].ToString(), out DateTime fParche)) {
                            response["FechaParche"] = fParche.ToString("yyyy-MM-dd");
                        } else {
                            response["FechaParche"] = "-";
                        }

                        response["Hardening"] = reader["PlantillaAplicada"] != DBNull.Value ? reader["PlantillaAplicada"].ToString() : "No aplicada";

// Lectura de los agentes y sus versiones
// 1. Extraemos los valores de Deep Security y limpiamos espacios
                        string agenteDS = reader["AgenteDeepSecurity"] != DBNull.Value ? reader["AgenteDeepSecurity"].ToString().Trim() : "";
                        string versionDS = reader["VersionDeepSecurity"] != DBNull.Value ? reader["VersionDeepSecurity"].ToString().Trim() : "";

                        // 2. Extraemos los valores de SentinelOne y limpiamos espacios
                        string agenteS1 = reader["AgenteSentinelone"] != DBNull.Value ? reader["AgenteSentinelone"].ToString().Trim() : "";
                        string versionS1 = reader["VersionSentinelone"] != DBNull.Value ? reader["VersionSentinelone"].ToString().Trim() : "";

                        List<string> agentesInstalados = new List<string>();

                        // 3. Validación estricta para DeepSecurity
                        if (!string.IsNullOrWhiteSpace(agenteDS) && 
                            agenteDS.ToLower() != "no detectado" && 
                            agenteDS.ToLower() != "no instalado" && 
                            agenteDS.ToLower() != "n/a" && 
                            agenteDS.ToUpper() != "NULL" && 
                            agenteDS.ToLower() != "offline" && // Nueva regla de exclusión
                            agenteDS != "-") 
                        {
                            agentesInstalados.Add(string.IsNullOrWhiteSpace(versionDS) ? "DeepSecurity" : $"DeepSecurity ({versionDS})");
                        }

                        // 4. Validación estricta para SentinelOne
                        if (!string.IsNullOrWhiteSpace(agenteS1) && 
                            agenteS1.ToLower() != "no detectado" && 
                            agenteS1.ToLower() != "no instalado" && 
                            agenteS1.ToLower() != "n/a" && 
                            agenteS1.ToUpper() != "NULL" && 
                            agenteS1.ToLower() != "offline" && // Nueva regla de exclusión
                            agenteS1 != "-") 
                        {
                            agentesInstalados.Add(string.IsNullOrWhiteSpace(versionS1) ? "SentinelOne" : $"SentinelOne ({versionS1})");
                        }

                        // 5. Asignamos el resultado final
                        if (agentesInstalados.Count > 0) 
                        {
                            response["AgenteSeguridad"] = string.Join(" / ", agentesInstalados);
                        } 
                        else 
                        {
                            // Si la base de datos reporta "Offline" en alguna de las columnas, asumimos que no hay información fiable y se muestra "No instalado".
                            response["AgenteSeguridad"] = "No Instalado"; 
                        }




                        string mon = reader["NombreMonitoreo"] != DBNull.Value ? reader["NombreMonitoreo"].ToString() : "";
                        string estMon = reader["EstadoMonitoreo"] != DBNull.Value ? reader["EstadoMonitoreo"].ToString() : "";
                        response["AgenteMonitoreo"] = !string.IsNullOrEmpty(mon) ? $"{mon} ({estMon})" : "Sin monitoreo";
                    }
                }
            }

            // 3. CONSULTA RED (Mapeando tus columnas exactas: DNS_Servidores, MAC_Address)
            var redList = new List<Dictionary<string, object>>();
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Servidores_Red WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha", conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        var redItem = new Dictionary<string, object>();
                        try { redItem["Adaptador"] = reader["Adaptador"]?.ToString() ?? "-"; } catch { redItem["Adaptador"] = "-"; }
                        try { redItem["IP"] = reader["Direccion_IP"]?.ToString() ?? "-"; } catch { redItem["IP"] = "-"; }
                        try { redItem["Mascara"] = reader["Mascara"]?.ToString() ?? "-"; } catch { redItem["Mascara"] = "-"; }
                        try { redItem["Gateway"] = reader["Gateway"]?.ToString() ?? "-"; } catch { redItem["Gateway"] = "-"; }
                        try { redItem["DNS"] = reader["DNS_Servidores"]?.ToString() ?? "-"; } catch { redItem["DNS"] = "-"; }
                        try { redItem["MAC"] = reader["MAC_Address"]?.ToString() ?? "-"; } catch { redItem["MAC"] = "-"; }
                        
                        redList.Add(redItem);
                    }
                }
            }
            response["Redes"] = redList;

            // 4. CONSULTA DISCOS (Mapeando tus columnas exactas: Capacidad_GB, EspacioLibre_GB)
            var discosList = new List<Dictionary<string, object>>();
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Servidores_Discos WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha", conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        var discoItem = new Dictionary<string, object>();
                        try { discoItem["Unidad"] = reader["LetraUnidad"]?.ToString() ?? "-"; } catch { discoItem["Unidad"] = "-"; }
                        try { discoItem["Etiqueta"] = reader["Etiqueta"]?.ToString() ?? "-"; } catch { discoItem["Etiqueta"] = "-"; }
                        try { discoItem["Capacidad"] = reader["Capacidad_GB"]?.ToString() ?? "0"; } catch { discoItem["Capacidad"] = "0"; }
                        try { discoItem["Libre"] = reader["EspacioLibre_GB"]?.ToString() ?? "0"; } catch { discoItem["Libre"] = "0"; }
                        try { discoItem["Uso"] = reader["PorcentajeUso"]?.ToString() ?? "0"; } catch { discoItem["Uso"] = "0"; }
                        
                        discosList.Add(discoItem);
                    }
                }
            }
            response["Discos"] = discosList;

            // 5. PROGRAMAS, SERVICIOS Y TAREAS
            var programasList = new List<Dictionary<string, object>>();
            using (SqlCommand cmd = new SqlCommand("SELECT NombrePrograma, Version FROM ProgramasInstalados WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha", conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        programasList.Add(new Dictionary<string, object> {
                            { "Nombre", reader["NombrePrograma"]?.ToString() ?? "-" },
                            { "Version", reader["Version"]?.ToString() ?? "-" }
                        });
                    }
                }
            }
            response["Programas"] = programasList;

            var serviciosList = new List<Dictionary<string, object>>();
            using (SqlCommand cmd = new SqlCommand("SELECT NombreServicio, Estado FROM Servicios WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha", conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        serviciosList.Add(new Dictionary<string, object> {
                            { "Nombre", reader["NombreServicio"]?.ToString() ?? "-" },
                            { "Estado", reader["Estado"]?.ToString() ?? "-" }
                        });
                    }
                }
            }
            response["Servicios"] = serviciosList;

            var tareasList = new List<Dictionary<string, object>>();
            using (SqlCommand cmd = new SqlCommand("SELECT NombreTarea, Estado FROM TareasProgramadas WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha", conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        tareasList.Add(new Dictionary<string, object> {
                            { "Nombre", reader["NombreTarea"]?.ToString() ?? "-" },
                            { "Estado", reader["Estado"]?.ToString() ?? "-" }
                        });
                    }
                }
            }
            response["Tareas"] = tareasList;

             // 6. CONSULTA DE USUARIOS (Con UNION para evitar duplicados)
            var usersList = new List<Dictionary<string, object>>();
            string queryUsers = @"
                SELECT NombreUsuario as Usuario, Tipo, Estado, Administrator as Admin 
                FROM Cuentas_Dominio 
                WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha
                UNION
                SELECT NombreUsuario as Usuario, Tipo, Estado, Administrador as Admin 
                FROM Cuentas_Locales 
                WHERE LOWER(Hostname) = LOWER(@Host) AND CAST(FechaConsulta AS DATE) = @Fecha";

            using (SqlCommand cmd = new SqlCommand(queryUsers, conn))
            {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Fecha", Convert.ToDateTime(targetDate));
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var user = new Dictionary<string, object>();
                        user["Usuario"] = reader["Usuario"]?.ToString() ?? "-";
                        user["Tipo"] = reader["Tipo"] != DBNull.Value ? reader["Tipo"].ToString() : "-";
                        user["Estado"] = reader["Estado"]?.ToString() ?? "-";
                        user["Admin"] = reader["Admin"]?.ToString() ?? "-";
                        usersList.Add(user);
                    }
                }
            }
            response["Usuarios"] = usersList;

            // 7. LÍNEA DE TIEMPO INTERACTIVA
            var histLabels = new List<string>();
            var histFullDates = new List<string>(); 
            var histData = new List<int>();
            
            string queryHist = "SELECT FechaConsulta, RAM_GB FROM Servidores_Core WHERE LOWER(Hostname) = LOWER(@Host) AND CONVERT(VARCHAR(7), FechaConsulta, 120) = @Mes ORDER BY FechaConsulta ASC";
            using (SqlCommand cmd = new SqlCommand(queryHist, conn)) {
                cmd.Parameters.AddWithValue("@Host", host);
                cmd.Parameters.AddWithValue("@Mes", targetMonth);
                using (SqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) { 
                        DateTime fechaObj = Convert.ToDateTime(reader["FechaConsulta"]);
                        histLabels.Add(fechaObj.ToString("dd/MMM")); 
                        histFullDates.Add(fechaObj.ToString("yyyy-MM-dd")); 
                        histData.Add(reader["RAM_GB"] != DBNull.Value ? Convert.ToInt32(reader["RAM_GB"]) : 0); 
                    }
                }
            }
            response["HistorialLabels"] = histLabels;
            response["HistorialFullDates"] = histFullDates;
            response["HistorialData"] = histData;
            response["Status"] = "OK"; 
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[API Error] {ex.Message}");
        return Results.Json(new { Status = "Error", Message = ex.Message });
    }
    
    return Results.Json(response);
});





// ==========================================
// ENDPOINT 3: INFORMES Y REPORTES (Iniciando con Ambiente)
// ==========================================
app.MapGet("/api/informes/{tipo}", (string tipo, IConfiguration config) =>
{
    var response = new Dictionary<string, object>();
    string connectionString = config.GetConnectionString("DefaultConnection");

    try
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            // Usamos la tabla derivada para asegurar que solo leemos el último estado de cada servidor
            string latestCoreCTE = @"
                SELECT c.* 
                FROM Servidores_Core c
                INNER JOIN (
                    SELECT Hostname, MAX(FechaConsulta) as MaxFecha
                    FROM Servidores_Core
                    GROUP BY Hostname
                ) latest ON c.Hostname = latest.Hostname AND c.FechaConsulta = latest.MaxFecha";

            if (tipo.ToLower() == "ambiente")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // 1. Datos para la gráfica (Agrupados)
                string queryResumen = $"SELECT ISNULL(Ambiente, 'Sin Definir') as Ambiente, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY Ambiente ORDER BY Total DESC";
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["Ambiente"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                // 2. Datos para la tabla de visualización
                string queryDetalle = $"SELECT Hostname, IP as Direccion_IP, SistemaOperativo, ISNULL(Ambiente, 'Sin Definir') as Ambiente FROM ({latestCoreCTE}) as t ORDER BY Ambiente, Hostname";
                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"]?.ToString() ?? "Sin IP";
                        srv["OS"] = reader["SistemaOperativo"]?.ToString() ?? "N/A";
                        srv["ValorAgrupador"] = reader["Ambiente"].ToString(); // Lo llamamos genérico para reusar la tabla después
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }

// NUEVO BLOQUE PARA ROL
            else if (tipo.ToLower() == "rol")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                string queryResumen = $"SELECT ISNULL(Rol, 'Sin Definir') as Rol, COUNT(*) as Total FROM ({latestCoreCTE}) as t GROUP BY Rol ORDER BY Total DESC";
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["Rol"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                string queryDetalle = $"SELECT Hostname, IP as Direccion_IP, SistemaOperativo, ISNULL(Rol, 'Sin Definir') as Rol FROM ({latestCoreCTE}) as t ORDER BY Rol, Hostname";
                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"]?.ToString() ?? "Sin IP";
                        srv["OS"] = reader["SistemaOperativo"]?.ToString() ?? "N/A";
                        srv["ValorAgrupador"] = reader["Rol"].ToString(); 
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }



// NUEVO BLOQUE PARA HARDENING (CORREGIDO PARA "No detectada")
            else if (tipo.ToLower() == "hardening")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // 1. Agrupación para la gráfica (Agregamos la condición LIKE '%No detectada%')
                string queryResumen = @"
                    WITH LatestCore AS (
                        SELECT Hostname FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    ),
                    LatestHardening AS (
                        SELECT Hostname, PlantillaAplicada FROM Servidores_Hardening
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Hardening sh WHERE sh.Hostname = Servidores_Hardening.Hostname)
                    )
                    SELECT 
                        CASE 
                            WHEN ISNULL(h.PlantillaAplicada, '') = '' OR h.PlantillaAplicada LIKE '%No detectada%' THEN 'No Aplicado' 
                            ELSE 'Aplicado' 
                        END as Estado, 
                        COUNT(*) as Total 
                    FROM LatestCore c
                    LEFT JOIN LatestHardening h ON c.Hostname = h.Hostname
                    GROUP BY 
                        CASE 
                            WHEN ISNULL(h.PlantillaAplicada, '') = '' OR h.PlantillaAplicada LIKE '%No detectada%' THEN 'No Aplicado' 
                            ELSE 'Aplicado' 
                        END";
                
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["Estado"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                // 2. Detalle de servidores
                string queryDetalle = @"
                    WITH LatestCore AS (
                        SELECT Hostname, IP as Direccion_IP, SistemaOperativo 
                        FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    ),
                    LatestHardening AS (
                        SELECT Hostname, PlantillaAplicada FROM Servidores_Hardening
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Hardening sh WHERE sh.Hostname = Servidores_Hardening.Hostname)
                    )
                    SELECT 
                        c.Hostname, 
                        c.Direccion_IP, 
                        c.SistemaOperativo, 
                        ISNULL(h.PlantillaAplicada, '') as Hardening 
                    FROM LatestCore c
                    LEFT JOIN LatestHardening h ON c.Hostname = h.Hostname
                    ORDER BY c.Hostname";

                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"]?.ToString() ?? "Sin IP";
                        srv["OS"] = reader["SistemaOperativo"]?.ToString() ?? "N/A";
                        
                        string valHardening = reader["Hardening"].ToString().Trim();
                        
                        // Validamos si está vacío o si dice "No detectada"
                        if (valHardening == "" || valHardening.ToLower().Contains("no detectada"))
                        {
                            srv["Hardening"] = "No detectada";
                            srv["Status"] = "No Aplicado";
                        }
                        else
                        {
                            srv["Hardening"] = valHardening;
                            srv["Status"] = "Aplicado";
                        }
                        
                        srv["ValorAgrupador"] = srv["Status"]; // Para que funcione el clic en la gráfica
                        
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }

// NUEVO BLOQUE PARA RED (Ajustado a la tabla Servidores_Red)
            else if (tipo.ToLower() == "red")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // 1. Agrupación para la gráfica (Por Gateway)
                string queryResumen = @"
                    WITH LatestRed AS (
                        SELECT Gateway 
                        FROM Servidores_Red 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Red sr WHERE sr.Hostname = Servidores_Red.Hostname)
                    )
                    SELECT 
                        CASE WHEN ISNULL(Gateway, '') = '' THEN 'Sin Gateway' ELSE Gateway END as Segmento, 
                        COUNT(*) as Total 
                    FROM LatestRed 
                    GROUP BY CASE WHEN ISNULL(Gateway, '') = '' THEN 'Sin Gateway' ELSE Gateway END
                    ORDER BY Total DESC";
                
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["Segmento"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                // 2. Detalle de servidores
                string queryDetalle = @"
                    WITH LatestRed AS (
                        SELECT Hostname, Direccion_IP, Mascara, Gateway, DNS_Servidores, MAC_Address
                        FROM Servidores_Red
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Red sr WHERE sr.Hostname = Servidores_Red.Hostname)
                    )
                    SELECT 
                        Hostname, 
                        ISNULL(Direccion_IP, 'N/A') as Direccion_IP, 
                        ISNULL(Mascara, 'N/A') as Mascara,
                        CASE WHEN ISNULL(Gateway, '') = '' THEN 'Sin Gateway' ELSE Gateway END as Gateway,
                        ISNULL(DNS_Servidores, 'N/A') as DNS,
                        ISNULL(MAC_Address, 'N/A') as MacAddress
                    FROM LatestRed
                    ORDER BY Hostname";

                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"].ToString();
                        srv["Mascara"] = reader["Mascara"].ToString();
                        srv["Gateway"] = reader["Gateway"].ToString();
                        srv["DNS"] = reader["DNS"].ToString();
                        srv["MacAddress"] = reader["MacAddress"].ToString();
                        
                        srv["ValorAgrupador"] = srv["Gateway"]; // Permite filtrar la tabla al hacer clic en la gráfica
                        
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }


// NUEVO BLOQUE PARA EOSL (Filtrado por 2008, 2012 y 2016)
            else if (tipo.ToLower() == "eosl")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // 1. Agrupación para la gráfica (Excluye 2019 y 2022)
                string queryResumen = @"
                    WITH LatestCore AS (
                        SELECT SistemaOperativo 
                        FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    )
                    SELECT 
                        ISNULL(SistemaOperativo, 'Desconocido') as OS, 
                        COUNT(*) as Total 
                    FROM LatestCore 
                    WHERE SistemaOperativo LIKE '%2008%' 
                       OR SistemaOperativo LIKE '%2012%' 
                       OR SistemaOperativo LIKE '%2016%'
                    GROUP BY ISNULL(SistemaOperativo, 'Desconocido')
                    ORDER BY Total DESC";
                
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["OS"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                // 2. Detalle de servidores (Excluye 2019 y 2022)
                string queryDetalle = @"
                    WITH LatestCore AS (
                        SELECT Hostname, IP as Direccion_IP, SistemaOperativo, Ambiente, Rol
                        FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    )
                    SELECT 
                        Hostname, 
                        ISNULL(Direccion_IP, 'Sin IP') as Direccion_IP, 
                        ISNULL(SistemaOperativo, 'N/A') as OS,
                        ISNULL(Ambiente, 'Sin Definir') as Ambiente,
                        ISNULL(Rol, 'Sin Definir') as Rol
                    FROM LatestCore
                    WHERE SistemaOperativo LIKE '%2008%' 
                       OR SistemaOperativo LIKE '%2012%' 
                       OR SistemaOperativo LIKE '%2016%'
                    ORDER BY Hostname";

                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"].ToString();
                        srv["OS"] = reader["OS"].ToString();
                        srv["Ambiente"] = reader["Ambiente"].ToString();
                        srv["Rol"] = reader["Rol"].ToString();
                        
                        srv["ValorAgrupador"] = srv["OS"]; 
                        
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }




// NUEVO BLOQUE PARA SERVIDORES ACTUALIZADOS (Gráfica de Instalado vs No Instalado por Año)
            else if (tipo.ToLower() == "parches")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // 1. Agrupación para la gráfica (Evalúa el año contra el año actual)
                string queryResumen = @"
                    WITH LatestParches AS (
                        SELECT Hostname, FechaInstalacion,
                               ROW_NUMBER() OVER(PARTITION BY Hostname ORDER BY FechaInstalacion DESC) as rn
                        FROM Parches 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Parches p WHERE p.Hostname = Parches.Hostname)
                    )
                    SELECT 
                        CASE 
                            WHEN YEAR(FechaInstalacion) = YEAR(GETDATE()) THEN 'Instalado'
                            ELSE 'No Instalado' 
                        END as Estado, 
                        COUNT(*) as Total 
                    FROM LatestParches 
                    WHERE rn = 1
                    GROUP BY 
                        CASE 
                            WHEN YEAR(FechaInstalacion) = YEAR(GETDATE()) THEN 'Instalado'
                            ELSE 'No Instalado' 
                        END
                    ORDER BY Total DESC";
                
                using (SqlCommand cmd = new SqlCommand(queryResumen, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        labels.Add(reader["Estado"].ToString());
                        data.Add(Convert.ToInt32(reader["Total"]));
                    }
                }

                // 2. Detalle cruzando Core y Parches (Validando año para el informe)
                string queryDetalle = @"
                    WITH LatestCore AS (
                        SELECT Hostname, SistemaOperativo, Ambiente 
                        FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    ),
                    LatestParches AS (
                        SELECT Hostname, ParcheKB, Descripcion, FechaInstalacion,
                               ROW_NUMBER() OVER(PARTITION BY Hostname ORDER BY FechaInstalacion DESC) as rn
                        FROM Parches
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Parches p WHERE p.Hostname = Parches.Hostname)
                    )
                    SELECT 
                        c.Hostname, 
                        ISNULL(c.SistemaOperativo, 'N/A') as OS,
                        ISNULL(c.Ambiente, 'Sin Definir') as Ambiente,
                        ISNULL(p.ParcheKB, 'Sin Parches') as ParcheKB,
                        ISNULL(p.Descripcion, 'N/A') as Descripcion,
                        p.FechaInstalacion
                    FROM LatestCore c
                    LEFT JOIN LatestParches p ON c.Hostname = p.Hostname AND p.rn = 1
                    ORDER BY p.FechaInstalacion DESC, c.Hostname";

                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    int anioActual = DateTime.Now.Year;

                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["OS"] = reader["OS"].ToString();
                        srv["Ambiente"] = reader["Ambiente"].ToString();
                        srv["ParcheKB"] = reader["ParcheKB"].ToString();
                        srv["Descripcion"] = reader["Descripcion"].ToString();
                        
                        if (reader["FechaInstalacion"] != DBNull.Value) 
                        {
                            DateTime fecha = Convert.ToDateTime(reader["FechaInstalacion"]);
                            srv["FechaInstalacion"] = fecha.ToString("yyyy-MM-dd");
                            
                            // Si es del año actual (ej. 2026), es Instalado. Si es anterior, No Instalado.
                            if(fecha.Year == anioActual) {
                                srv["Estado"] = "Instalado";
                            } else {
                                srv["Estado"] = "No Instalado";
                            }
                        } 
                        else 
                        {
                            srv["FechaInstalacion"] = "N/A";
                            srv["Estado"] = "No Instalado";
                        }
                        
                        srv["ValorAgrupador"] = srv["Estado"]; // Permite vincular el clic de la gráfica con la tabla
                        detalles.Add(srv);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }


// NUEVO BLOQUE PARA ANTIVIRUS (Solo 3 datos, excluyendo "Offline" y cambiando a "No detectado")
            else if (tipo.ToLower() == "antivirus")
            {
                var labels = new List<string>();
                var data = new List<int>();
                var detalles = new List<Dictionary<string, string>>();

                // Diccionario con el nuevo texto "No detectado"
                var conteoAgentes = new Dictionary<string, int>() {
                    { "DeepSecurity", 0 },
                    { "SentinelOne", 0 },
                    { "No detectado", 0 } 
                };

                string queryDetalle = @"
                    WITH LatestCore AS (
                        SELECT Hostname, IP as Direccion_IP, SistemaOperativo, Ambiente
                        FROM Servidores_Core 
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM Servidores_Core sc WHERE sc.Hostname = Servidores_Core.Hostname)
                    ),
                    LatestAV AS (
                        SELECT Hostname, AgenteSentinelone, VersionSentinelone, AgenteDeepSecurity, VersionDeepSecurity
                        FROM AgenteAntivirus
                        WHERE FechaConsulta = (SELECT MAX(FechaConsulta) FROM AgenteAntivirus av WHERE av.Hostname = AgenteAntivirus.Hostname)
                    )
                    SELECT 
                        c.Hostname, 
                        ISNULL(c.Direccion_IP, 'Sin IP') as Direccion_IP, 
                        ISNULL(c.SistemaOperativo, 'N/A') as OS,
                        ISNULL(c.Ambiente, 'Sin Definir') as Ambiente,
                        ISNULL(av.AgenteSentinelone, '') as AgenteS1,
                        ISNULL(av.VersionSentinelone, '') as VerS1,
                        ISNULL(av.AgenteDeepSecurity, '') as AgenteDS,
                        ISNULL(av.VersionDeepSecurity, '') as VerDS
                    FROM LatestCore c
                    LEFT JOIN LatestAV av ON c.Hostname = av.Hostname
                    ORDER BY c.Hostname";

                using (SqlCommand cmd = new SqlCommand(queryDetalle, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var srv = new Dictionary<string, string>();
                        srv["Hostname"] = reader["Hostname"].ToString();
                        srv["IP"] = reader["Direccion_IP"].ToString();
                        srv["OS"] = reader["OS"].ToString();
                        srv["Ambiente"] = reader["Ambiente"].ToString();

                        string agenteDS = reader["AgenteDS"].ToString().Trim();
                        string versionDS = reader["VerDS"].ToString().Trim();
                        string agenteS1 = reader["AgenteS1"].ToString().Trim();
                        string versionS1 = reader["VerS1"].ToString().Trim();

                        List<string> agentesInstalados = new List<string>();
                        bool hasDS = false;
                        bool hasS1 = false;

                        if (!string.IsNullOrWhiteSpace(agenteDS) && 
                            agenteDS.ToLower() != "no detectado" && 
                            agenteDS.ToLower() != "no instalado" && 
                            agenteDS.ToLower() != "n/a" && 
                            agenteDS.ToUpper() != "NULL" && 
                            agenteDS.ToLower() != "offline" && 
                            agenteDS != "-") 
                        {
                            hasDS = true;
                            agentesInstalados.Add(string.IsNullOrWhiteSpace(versionDS) ? "DeepSecurity" : $"DeepSecurity ({versionDS})");
                        }

                        if (!string.IsNullOrWhiteSpace(agenteS1) && 
                            agenteS1.ToLower() != "no detectado" && 
                            agenteS1.ToLower() != "no instalado" && 
                            agenteS1.ToLower() != "n/a" && 
                            agenteS1.ToUpper() != "NULL" && 
                            agenteS1.ToLower() != "offline" && 
                            agenteS1 != "-") 
                        {
                            hasS1 = true;
                            agentesInstalados.Add(string.IsNullOrWhiteSpace(versionS1) ? "SentinelOne" : $"SentinelOne ({versionS1})");
                        }

                        // Cambio a "No detectado" para la gráfica
                        string categoriaGrafica = "No detectado";
                        if (hasDS) categoriaGrafica = "DeepSecurity";
                        else if (hasS1) categoriaGrafica = "SentinelOne";

                        conteoAgentes[categoriaGrafica]++;

                        if (agentesInstalados.Count > 0) 
                        {
                            srv["Antivirus"] = string.Join(" / ", agentesInstalados);
                            srv["Estado"] = "Instalado";
                        } 
                        else 
                        {
                            srv["Antivirus"] = "No detectado";
                            srv["Estado"] = "No detectado"; // Cambio a "No detectado" en la tabla
                        }
                        
                        srv["ValorAgrupador"] = categoriaGrafica; 
                        detalles.Add(srv);
                    }
                }

                foreach(var kvp in conteoAgentes)
                {
                    if(kvp.Value > 0)
                    {
                        labels.Add(kvp.Key);
                        data.Add(kvp.Value);
                    }
                }

                response["Labels"] = labels;
                response["Data"] = data;
                response["Detalles"] = detalles;
                response["Status"] = "OK";
            }



            else
            {
                response["Status"] = "Error";
                response["Message"] = "Tipo de reporte no configurado aún.";
            }
        }
    }
    catch (Exception ex)
    {
        return Results.Json(new { Status = "Error", Message = ex.Message });
    }
    
    return Results.Json(response);
});



//var app = builder.Build();

//app.UseCors("AllowFrontend");

// TODOS LOS MAPGET
//app.MapGet("/api/dashboard", ...);
//app.MapGet("/api/server", ...);

app.Run();
-- 1. CORE
DROP TABLE IF EXISTS Servidores_Core;
DROP TABLE IF EXISTS Servidores_Hardening;
DROP TABLE IF EXISTS AgenteAntivirus;
DROP TABLE IF EXISTS AgenteMonitoreo;
DROP TABLE IF EXISTS Servidores_Discos;

DROP TABLE IF EXISTS Servidores_Red;

DROP TABLE IF EXISTS Cuentas_Dominio;
DROP TABLE IF EXISTS Cuentas_Locales;

DROP TABLE IF EXISTS Parches;
DROP TABLE IF EXISTS ProgramasInstalados;
DROP TABLE IF EXISTS TareasProgramadas;
DROP TABLE IF EXISTS Servicios;
DROP TABLE IF EXISTS Servidores_IIS_Sitios;


SELECT * FROM ProgramasInstalados;
SELECT * FROM TareasProgramadas;
SELECT * FROM Servicios;

SELECT * FROM Servidores_Core;

SELECT * FROM Cuentas_Locales;
SELECT * FROM Cuentas_Dominio;

CREATE TABLE Servidores_Core (
    Hostname          VARCHAR(100) NOT NULL,
    FechaConsulta     DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL,
    IP                VARCHAR(50)  NULL,
    TipoEquipo        VARCHAR(50)  NULL,
    Ambiente          VARCHAR(50)  NULL,
    Rol               VARCHAR(100) NULL,
    EstadoConexion    VARCHAR(50)  NULL,
    Fabricante        VARCHAR(100) NULL,
    Modelo            VARCHAR(100) NULL,
    CPU_Modelo        VARCHAR(150) NULL,
    CPU               VARCHAR(150) NULL,
    RAM_GB            INT NULL,
    SistemaOperativo  VARCHAR(150) NULL,
    OS_Version        VARCHAR(50)  NULL,
    OS_Build          VARCHAR(50)  NULL,
    Dominio           VARCHAR(100) NULL,
    Uptime_Dias       DECIMAL(10,2) NULL,
    ReinicioPendiente VARCHAR(20)  NULL,
    PRIMARY KEY (Hostname, FechaConsulta)
);

-- 2. HARDENING
CREATE TABLE Servidores_Hardening (
    Hostname          VARCHAR(100) NOT NULL,
    FechaConsulta     DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL,
    IP                VARCHAR(50)  NULL,
    PlantillaAplicada VARCHAR(150) NULL,
    PRIMARY KEY (Hostname, FechaConsulta)
);

-- 3. AGENTE ANTIVIRUS
CREATE TABLE AgenteAntivirus (
    Hostname             VARCHAR(100) NOT NULL,
    FechaConsulta        DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL,
    AgenteSentinelone    VARCHAR(50)  NULL,
    VersionSentinelone   VARCHAR(50)  NULL,
    FechaInstalacionSO1  DATETIME     NULL,
    AgenteDeepSecurity   VARCHAR(50)  NULL,
    VersionDeepSecurity  VARCHAR(50)  NULL,
    FechaInstalacionDS   DATETIME     NULL,
    PRIMARY KEY (Hostname, FechaConsulta)
);

-- 4. AGENTE MONITOREO
CREATE TABLE AgenteMonitoreo (
    Hostname         VARCHAR(100) NOT NULL,
    FechaConsulta    DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL,
    IP               VARCHAR(50)  NULL,
    AgenteMonitoreo  VARCHAR(50)  NULL,
    EstadoMonitoreo  VARCHAR(50)  NULL, 
    PRIMARY KEY (Hostname, FechaConsulta)
);

-- TABLAS HIJAS (Sin PK estricta para evitar bloqueos, pero con FechaConsulta)
CREATE TABLE Servidores_Discos (
    Hostname VARCHAR(100) NOT NULL, 
	LetraUnidad VARCHAR(10) NOT NULL, 
	Etiqueta VARCHAR(100) NULL, 
	File_System VARCHAR(20) NULL, 
	Capacidad_GB DECIMAL(10,2) NULL, 
	EspacioLibre_GB DECIMAL(10,2) NULL, 
	PorcentajeUso DECIMAL(5,2) NULL, 
	FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL
);



CREATE TABLE Servidores_Red (
    Hostname VARCHAR(100) NOT NULL, 
	Adaptador VARCHAR(150) NOT NULL, 
	MAC_Address VARCHAR(50) NULL, 
	Direccion_IP VARCHAR(50) NULL, 
	Mascara VARCHAR(50) NULL, 
	Gateway VARCHAR(50) NULL, 
	DNS_Servidores VARCHAR(150) NULL, 
	FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL
);


CREATE TABLE Cuentas_Dominio (
Hostname VARCHAR(100) NOT NULL, 
NombreUsuario VARCHAR(100) NOT NULL,
Tipo VARCHAR(50) NULL,
Estado VARCHAR(50) NULL, 
Administrator VARCHAR(20) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);


CREATE TABLE Cuentas_Locales (
Hostname VARCHAR(100) NOT NULL, 
NombreUsuario VARCHAR(100) NOT NULL,
Tipo VARCHAR(50) NULL,
Estado VARCHAR(20) NULL, 
Administrador VARCHAR(20) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);


CREATE TABLE Parches (
Hostname VARCHAR(100) NOT NULL, 
ParcheKB VARCHAR(100) NOT NULL, 
Descripcion VARCHAR(255) NULL, 
FechaInstalacion DATETIME NULL, 
Estado VARCHAR(50) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);



CREATE TABLE ProgramasInstalados (
Hostname VARCHAR(100) NOT NULL, 
NombrePrograma VARCHAR(200) NOT NULL, 
Version VARCHAR(100) NULL, 
Editor VARCHAR(150) NULL, 
FechaInstalacion VARCHAR(50) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);


CREATE TABLE TareasProgramadas (
Hostname VARCHAR(100) NOT NULL, 
NombreTarea VARCHAR(255) NOT NULL, 
Estado VARCHAR(50) NULL, 
SiguienteEjecucion DATETIME NULL, 
UltimaEjecucion DATETIME NULL, 
UltimoResultado VARCHAR(100) NULL, 
UsuarioEjecucion VARCHAR(100) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);


CREATE TABLE Servicios (
Hostname VARCHAR(100) NOT NULL, 
NombreServicio VARCHAR(150) NOT NULL, 
NombreMostrar VARCHAR(255) NULL, 
Estado VARCHAR(50) NULL, 
ModoInicio VARCHAR(50) NULL, 
CuentaLogon VARCHAR(100) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);


CREATE TABLE Servidores_IIS_Sitios (
Hostname VARCHAR(100) NOT NULL, 
NombreSitio VARCHAR(150) NOT NULL, 
Estado VARCHAR(50) NULL, 
ApplicationPool VARCHAR(150) NULL, 
PuertoBindings VARCHAR(250) NULL, 
RutaFisica VARCHAR(300) NULL, 
FechaConsulta DATE DEFAULT CAST(GETDATE() AS DATE) NOT NULL);
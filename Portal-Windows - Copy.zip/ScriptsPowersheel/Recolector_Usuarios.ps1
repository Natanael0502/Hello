# ==========================================
# RECOLECTOR DE CUENTAS (Locales y Dominio) -> SQL SERVER (MODO HIST�RICO)
# ==========================================
$serversFile = "C:\ServersIT\servers.txt";

if (-not (Test-Path $serversFile)) {
    Write-Host "Archivo servers.txt no encontrado." -ForegroundColor Red;
    exit;
}

[string[]]$servers = (Get-Content $serversFile -ErrorAction Stop) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" };
$sessionOption = New-PSSessionOption -OpenTimeout 60000 -CancelTimeout 60000 -OperationTimeout 60000;

# ==========================================
# CEREBRO REMOTO (Extrae Usuarios Locales, Admins y RDP mediante ADSI)
# ==========================================
$scriptBlockRemoto = {
    $ErrorActionPreference = "SilentlyContinue";
    $hostLocal = $env:COMPUTERNAME.ToUpper();

    try {
        $usuariosConsolidados = @();

        # SIDs Universales para evitar problemas de idioma
        $sidAdmin = "S-1-5-32-544"; # Administradores
        $sidRDP   = "S-1-5-32-555"; # Usuarios de escritorio remoto

        # Funci�n interna s�per robusta usando ADSI
        function Obtener-MiembrosGrupoADSI {
            param($sid)
            $nombres = @();
            try {
                $objSID = New-Object System.Security.Principal.SecurityIdentifier($sid);
                $groupNameCompleto = $objSID.Translate([System.Security.Principal.NTAccount]).Value;
                $groupName = $groupNameCompleto.Split('\')[-1]; 

                $adsi = [ADSI]"WinNT://$env:COMPUTERNAME/$groupName,group";
                $miembros = $adsi.psbase.Invoke("Members");

                foreach ($m in $miembros) {
                    $path = $m.GetType().InvokeMember("AdsPath", 'GetProperty', $null, $m, $null);
                    $partes = $path.Split('/');
                    $dominio = $partes[-2];
                    $usuario = $partes[-1];
                    $nombres += "$dominio\$usuario".ToUpper();
                }
            } catch {}
            return $nombres;
        }

        # Extraer miembros de los grupos privilegiados
        $adminNames = Obtener-MiembrosGrupoADSI -sid $sidAdmin;
        $rdpNames   = Obtener-MiembrosGrupoADSI -sid $sidRDP;

        # Obtener TODOS los usuarios locales para el estatus
        $localUsers = Get-CimInstance -Class Win32_UserAccount -Filter "LocalAccount='True'" -ErrorAction SilentlyContinue;
        if (-not $localUsers) {
            $localUsers = Get-WmiObject -Class Win32_UserAccount -Filter "LocalAccount='True'" -ErrorAction SilentlyContinue;
        }
        
        $procesados = @{};

        # PASO 1: Analizar usuarios locales
        if ($localUsers) {
            foreach ($usr in ($localUsers)) {
                $domain = $usr.Domain;
                $name = $usr.Name;
                $key = "$domain\$name".ToUpper();
                
                $esAdmin = if ($adminNames -contains $key) { "Si" } else { "No" };
                $estado  = if ($usr.Disabled) { "Desactivado" } else { "Activo" };

                $procesados[$key] = $true;

                $usuariosConsolidados += [PSCustomObject]@{
                    Hostname = $hostLocal;
                    Usuario  = $name;
                    Tipo     = "Local";
                    Estado   = $estado;
                    EsAdmin  = $esAdmin;
                };
            }
        }

        # PASO 2: Analizar cuentas de Dominio (o Grupos de Red)
        $todosPrivilegiados = @();
        if ($adminNames) { $todosPrivilegiados += $adminNames }
        if ($rdpNames) { $todosPrivilegiados += $rdpNames }

        $todosPrivilegiados = $todosPrivilegiados | Select-Object -Unique;

        if ($todosPrivilegiados) {
            foreach ($privKey in ($todosPrivilegiados)) {
                if (-not $procesados.ContainsKey($privKey)) {
                    
                    $esAdmin = if ($adminNames -contains $privKey) { "Si" } else { "No" };
                    $procesados[$privKey] = $true;

                    $usuariosConsolidados += [PSCustomObject]@{
                        Hostname = $hostLocal;
                        Usuario  = $privKey;
                        Tipo     = "Dominio";
                        Estado   = "Activo";
                        EsAdmin  = $esAdmin;
                    };
                }
            }
        }

        [PSCustomObject]@{
            Hostname = $hostLocal;
            Usuarios = $usuariosConsolidados;
        };
    } 
    catch {
        [PSCustomObject]@{
            Hostname = $hostLocal;
            Usuarios = @();
        };
    }
};

# ==========================================
# EJECUCI�N REMOTA Y RECOLECCI�N
# ==========================================
$infoRemota = @();
$tamanioLote = 50;

Write-Host "Iniciando escaneo de Cuentas y Accesos por WinRM..." -ForegroundColor Cyan;

for ($i = 0; $i -lt $servers.Count; $i += $tamanioLote) {
    $lote = $servers[$i..([math]::Min($i + $tamanioLote - 1, $servers.Count - 1))];
    $infoRemota += Invoke-Command -ComputerName $lote -ScriptBlock $scriptBlockRemoto -SessionOption $sessionOption -ThrottleLimit $tamanioLote -ErrorAction SilentlyContinue;
}

$resultados = @(foreach ($item in ($infoRemota)) { $item });
$servidoresConRespuesta = @($resultados | Select-Object -ExpandProperty Hostname -Unique);

$listaFinalUsuarios = @();

# Juntar todos los usuarios de los servidores que respondieron
foreach ($res in ($resultados)) {
    if ($res.Usuarios) {
        foreach ($u in ($res.Usuarios)) {
            $listaFinalUsuarios += $u;
        }
    }
}

# Procesar los servidores ca�dos (Offline)
foreach ($srv in ($servers)) {
    if ($srv -notin $servidoresConRespuesta) {
        $listaFinalUsuarios += [PSCustomObject]@{
            Hostname = $srv.ToUpper();
            Usuario  = "Offline";
            Tipo     = "Offline";
            Estado   = "-";
            EsAdmin  = "-";
        };
    }
}

# ==========================================
# FASE SQL: INSERCI�N MASIVA (HIST�RICO)
# ==========================================
$connectionString = "Server=RXGSWSO01;Database=ServerWindows;User Id=sa;Password=N@7an2026#;";
$conn = New-Object System.Data.SqlClient.SqlConnection($connectionString);

try {
    $conn.Open();
    $transaction = $conn.BeginTransaction();
    $cmd = $conn.CreateCommand();
    $cmd.Transaction = $transaction;

    Write-Host "Escribiendo registros en SQL (Modo Hist�rico sin borrar)..." -ForegroundColor Yellow;

    # Separar listas
    $listaLocales = $listaFinalUsuarios | Where-Object { $_.Tipo -eq "Local" -or $_.Tipo -eq "Offline" };
    $listaDominio = $listaFinalUsuarios | Where-Object { $_.Tipo -eq "Dominio" };

    # 1. Insertar Cuentas Locales (y reportar los Offline aqu�)
    $cmd.CommandText = @"
        INSERT INTO Cuentas_Locales (Hostname, NombreUsuario, Tipo, Estado, Administrador) 
        VALUES (@Hostname, @NombreUsuario, @Tipo, @Estado, @Administrador)
"@;
    foreach ($item in ($listaLocales)) {
        $cmd.Parameters.Clear();
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname);
        [void]$cmd.Parameters.AddWithValue("@NombreUsuario", $item.Usuario);
        [void]$cmd.Parameters.AddWithValue("@Tipo", $item.Tipo);
        [void]$cmd.Parameters.AddWithValue("@Estado", $item.Estado);
        [void]$cmd.Parameters.AddWithValue("@Administrador", $item.EsAdmin);
        [void]$cmd.ExecuteNonQuery();
    }
    Write-Host "- Cuentas Locales insertadas."

    # 2. Insertar Cuentas de Dominio
    $cmd.CommandText = @"
        INSERT INTO Cuentas_Dominio (Hostname, NombreUsuario, Tipo, Estado, Administrator) 
        VALUES (@Hostname, @NombreUsuario, @Tipo, @Estado, @Administrator)
"@;
    foreach ($item in ($listaDominio)) {
        $cmd.Parameters.Clear();
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname);
        [void]$cmd.Parameters.AddWithValue("@NombreUsuario", $item.Usuario);
        [void]$cmd.Parameters.AddWithValue("@Tipo", $item.Tipo);
        [void]$cmd.Parameters.AddWithValue("@Estado", $item.Estado);
        [void]$cmd.Parameters.AddWithValue("@Administrator", $item.EsAdmin);
        [void]$cmd.ExecuteNonQuery();
    }
    Write-Host "- Cuentas de Dominio insertadas."

    $transaction.Commit();
    Write-Host "�M�dulo de Cuentas y Accesos insertado en Base de Datos exitosamente!" -ForegroundColor Green;
}
catch {
    if ($transaction) { $transaction.Rollback(); }
    Write-Host "Error al guardar en SQL: $_" -ForegroundColor Red;
}
finally {
    $conn.Close();
}
﻿# ==========================================
# PORTAL WINDOWS SERVERS - BLOQUE 2: SEGURIDAD Y MONITOREO (HISTÓRICO)
# ==========================================
$serversFile = "C:\ServersIT\servers.txt" # Ajusta a la ruta real de tu archivo
if (-not (Test-Path $serversFile)) {
    Write-Host "Archivo servers.txt no encontrado." -ForegroundColor Red
    exit
}

[string[]]$servers = Get-Content $serversFile -ErrorAction Stop | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
$sessionOption = New-PSSessionOption -OpenTimeout 60000 -CancelTimeout 60000 -OperationTimeout 60000

# ==========================================
# CEREBRO REMOTO (Extrae Antivirus y Monitoreo)
# ==========================================
$scriptBlockRemoto = {
    $ErrorActionPreference = "SilentlyContinue"
    $hostLocal = $env:COMPUTERNAME.ToUpper()

    try {
        # --- 0. IP PRINCIPAL (Para la tabla de monitoreo - Optimizado) ---
        $redesIP = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled = 'True'"
        $ipCore = ""
        if ($redesIP) {
            $ipCore = $redesIP | Select-Object -ExpandProperty IPAddress | Where-Object { $_ -match '\.' } | Select-Object -First 1
        }

        # --- 1. AGENTE ANTIVIRUS (Registro + Servicios) ---
        $avPaths = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
        )
        $installedSoftware = Get-ItemProperty $avPaths -ErrorAction SilentlyContinue | Select-Object DisplayName, DisplayVersion, InstallDate

        # Buscar SentinelOne
        $s1Reg = $installedSoftware | Where-Object { $_.DisplayName -match "Sentinel" } | Select-Object -First 1
        $s1Svc = Get-Service -Name "SentinelAgent", "Sentinel*" -ErrorAction SilentlyContinue | Where-Object Status -eq 'Running' | Select-Object -First 1

        $s1Agente  = "No Instalado"
        $s1Version = $null
        $s1Fecha   = $null

        if ($s1Reg) {
            $s1Agente  = "SentinelOne"
            $s1Version = $s1Reg.DisplayVersion
            if ($s1Reg.InstallDate -match '^(\d{4})(\d{2})(\d{2})$') { 
                $s1Fecha = "$($matches[1])-$($matches[2])-$($matches[3])" 
            }
        } elseif ($s1Svc) {
            $s1Agente  = "SentinelOne"
            $s1Version = "Desconocida (Servicio Activo)"
        }

        # Buscar Deep Security
        $dsReg = $installedSoftware | Where-Object { $_.DisplayName -match "Trend Micro|Deep Security" } | Select-Object -First 1
        $dsSvc = Get-Service -Name "ds_agent" -ErrorAction SilentlyContinue | Where-Object Status -eq 'Running' | Select-Object -First 1

        $dsAgente  = "No Instalado"
        $dsVersion = $null
        $dsFecha   = $null

        if ($dsReg) {
            $dsAgente  = "DeepSecurity"
            $dsVersion = $dsReg.DisplayVersion
            if ($dsReg.InstallDate -match '^(\d{4})(\d{2})(\d{2})$') { 
                $dsFecha = "$($matches[1])-$($matches[2])-$($matches[3])" 
            }
        } elseif ($dsSvc) {
            $dsAgente  = "DeepSecurity"
            $dsVersion = "Desconocida (Servicio Activo)"
        }

        $avData = [PSCustomObject]@{
            Hostname            = $hostLocal
            AgenteSentinelone   = $s1Agente
            VersionSentinelone  = $s1Version
            FechaInstalacionSO1 = $s1Fecha
            AgenteDeepSecurity  = $dsAgente
            VersionDeepSecurity = $dsVersion
            FechaInstalacionDS  = $dsFecha
        }

        # --- 2. AGENTE MONITOREO (Detección por Servicios) ---
        $dynatraceService = Get-Service -Name "Dynatrace*", "OneAgent*" -ErrorAction SilentlyContinue | Select-Object -First 1
        $nagiosService    = Get-Service -Name "NSClient++", "NCPA*", "nscp" -ErrorAction SilentlyContinue | Select-Object -First 1

        $agenteMonitoreo = "Aria Operations" # Por defecto
        $estadoMonitoreo = "Activo"

        if ($dynatraceService) {
            $agenteMonitoreo = "Dynatrace"
            $estadoMonitoreo = if ($dynatraceService.Status -eq 'Running') { "Activo" } else { "Inactivo" }
        }
        elseif ($nagiosService) {
            $agenteMonitoreo = "Nagios"
            $estadoMonitoreo = if ($nagiosService.Status -eq 'Running') { "Activo" } else { "Inactivo" }
        }

        $monData = [PSCustomObject]@{
            Hostname        = $hostLocal
            IP              = $ipCore
            AgenteMonitoreo = $agenteMonitoreo
            EstadoMonitoreo = $estadoMonitoreo
        }

        # Empaquetar
        [PSCustomObject]@{
            Hostname  = $hostLocal
            Antivirus = $avData
            Monitoreo = $monData
        }
    }
    catch {
        [PSCustomObject]@{
            Hostname  = $hostLocal
            Antivirus = $null
            Monitoreo = $null
        }
    }
}

# ==========================================
# EJECUCIÓN REMOTA (Optimizado sin For manual)
# ==========================================
$tamanioLote = 50
Write-Host "Iniciando escaneo de Seguridad y Monitoreo por WinRM en $($servers.Count) servidores..." -ForegroundColor Cyan

# Invoke-Command maneja el loteo automáticamente con -ThrottleLimit, siendo mucho más rápido
$infoRemota = Invoke-Command -ComputerName $servers -ScriptBlock $scriptBlockRemoto -SessionOption $sessionOption -ThrottleLimit $tamanioLote -ErrorAction SilentlyContinue

$servidoresConRespuesta = @($infoRemota | Select-Object -ExpandProperty Hostname -Unique)

$listaAntivirus = @()
$listaMonitoreo = @()

foreach ($res in $infoRemota) {
    if ($res.Antivirus) { $listaAntivirus += $res.Antivirus }
    if ($res.Monitoreo) { $listaMonitoreo += $res.Monitoreo }
}

# Procesar los caídos (Offline)
foreach ($srv in $servers) {
    if ($srv -notin $servidoresConRespuesta) {
        $hostOff = $srv.ToUpper()
        
        $listaAntivirus += [PSCustomObject]@{
            Hostname            = $hostOff
            AgenteSentinelone   = "Offline"
            VersionSentinelone  = $null
            FechaInstalacionSO1 = $null
            AgenteDeepSecurity  = "Offline"
            VersionDeepSecurity = $null
            FechaInstalacionDS  = $null
        }

        $listaMonitoreo += [PSCustomObject]@{
            Hostname        = $hostOff
            IP              = "-"
            AgenteMonitoreo = "Offline"
            EstadoMonitoreo = "Offline"
        }
    }
}

# ==========================================
# FASE SQL: INSERCIÓN (MODO HISTÓRICO - SIN TRUNCATE)
# ==========================================
$connectionString = "Server=RXGSWSO01;Database=ServerWindows;User Id=sa;Password=N@7an2026#;"
$conn = New-Object System.Data.SqlClient.SqlConnection($connectionString)

try {
    $conn.Open()
    $transaction = $conn.BeginTransaction()
    $cmd = $conn.CreateCommand()
    $cmd.Transaction = $transaction

    Write-Host "Iniciando guardado de historia en SQL (sin borrar lo anterior)..." -ForegroundColor Yellow

    # 1. Borrar SÓLO los datos del día de HOY para evitar errores de llave primaria si se corre 2 veces hoy
    $cmd.CommandText = "DELETE FROM AgenteAntivirus WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM AgenteMonitoreo WHERE FechaConsulta = CAST(GETDATE() AS DATE);"
    [void]$cmd.ExecuteNonQuery()

    # 2. Insertar Antivirus (Con FechaConsulta)
    $cmd.CommandText = @"
        INSERT INTO AgenteAntivirus (Hostname, AgenteSentinelone, VersionSentinelone, FechaInstalacionSO1, AgenteDeepSecurity, VersionDeepSecurity, FechaInstalacionDS, FechaConsulta) 
        VALUES (@Hostname, @AgenteS1, @VerS1, @FechaS1, @AgenteDS, @VerDS, @FechaDS, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaAntivirus) {
        $cmd.Parameters.Clear()
        
        # Evaluamos los nulos ANTES de pasarlos a los parámetros
        $verS1   = if ([string]::IsNullOrWhiteSpace($item.VersionSentinelone)) { [DBNull]::Value } else { $item.VersionSentinelone }
        $fechaS1 = if ([string]::IsNullOrWhiteSpace($item.FechaInstalacionSO1)) { [DBNull]::Value } else { $item.FechaInstalacionSO1 }
        $verDS   = if ([string]::IsNullOrWhiteSpace($item.VersionDeepSecurity)) { [DBNull]::Value } else { $item.VersionDeepSecurity }
        $fechaDS = if ([string]::IsNullOrWhiteSpace($item.FechaInstalacionDS)) { [DBNull]::Value } else { $item.FechaInstalacionDS }

        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@AgenteS1", $item.AgenteSentinelone)
        [void]$cmd.Parameters.AddWithValue("@VerS1", $verS1)
        [void]$cmd.Parameters.AddWithValue("@FechaS1", $fechaS1)
        [void]$cmd.Parameters.AddWithValue("@AgenteDS", $item.AgenteDeepSecurity)
        [void]$cmd.Parameters.AddWithValue("@VerDS", $verDS)
        [void]$cmd.Parameters.AddWithValue("@FechaDS", $fechaDS)
        
        [void]$cmd.ExecuteNonQuery()
    }

    # 3. Insertar Monitoreo (Con FechaConsulta)
    $cmd.CommandText = @"
        INSERT INTO AgenteMonitoreo (Hostname, IP, AgenteMonitoreo, EstadoMonitoreo, FechaConsulta) 
        VALUES (@Hostname, @IP, @AgenteMon, @EstadoMon, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaMonitoreo) {
        $cmd.Parameters.Clear()
        
        $ipValor = if ([string]::IsNullOrWhiteSpace($item.IP)) { "-" } else { $item.IP }

        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@IP", $ipValor)
        [void]$cmd.Parameters.AddWithValue("@AgenteMon", $item.AgenteMonitoreo)
        [void]$cmd.Parameters.AddWithValue("@EstadoMon", $item.EstadoMonitoreo)
        
        [void]$cmd.ExecuteNonQuery()
    }

    $transaction.Commit()
    Write-Host "¡Módulo de Seguridad y Monitoreo completado! Datos del día $(Get-Date -Format 'dd-MM-yyyy') guardados exitosamente." -ForegroundColor Green
}
catch {
    if ($transaction) { $transaction.Rollback() }
    Write-Host "Error al guardar en SQL: $_" -ForegroundColor Red
}
finally {
    $conn.Close()
}
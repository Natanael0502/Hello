# ==========================================
# PORTAL WINDOWS SERVERS - BLOQUE 1: INFRAESTRUCTURA (HIST�RICO)
# ==========================================
$serversFile = "C:\ServersIT\servers.txt" # Ajusta a la ruta real de tu archivo
if (-not (Test-Path $serversFile)) {
    Write-Host "Archivo servers.txt no encontrado." -ForegroundColor Red
    exit
}

[string[]]$servers = Get-Content $serversFile -ErrorAction Stop | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }

$sessionOption = New-PSSessionOption -OpenTimeout 60000 -CancelTimeout 60000 -OperationTimeout 60000

# ==========================================
# CEREBRO REMOTO (Extrae Core, Hardening, Discos y Red)
# ==========================================
$scriptBlockRemoto = {
    $ErrorActionPreference = "SilentlyContinue"
    $hostLocal = $env:COMPUTERNAME.ToUpper()

    try {
        # --- 1. AMBIENTE Y ROL ---
        $ambiente = if ($hostLocal -match "^(TD|RD|INVD|MS)") { "Desarrollo" }
                    elseif ($hostLocal -match "^(RQ|INVQ|TQ)") { "QA" }
                    elseif ($hostLocal -match "^(RX)") { "Tools" }
                    elseif ($hostLocal -match "^(DR|VIR)") { "DRP" }
                    elseif ($hostLocal -match "^(RP)") { "Produccion" }
                    else { "Producci�n" }

        $hasSQLServices = Get-Service -Name "MSSQL*", "Oracle*", "MySQL*", "postgresql*" -ErrorAction SilentlyContinue | Where-Object Status -eq "Running"
        $hasSQL = [bool]$hasSQLServices -or ($hostLocal -match "SQL|DB|BD")
        $hasIIS = (Get-Service -Name "W3SVC" -ErrorAction SilentlyContinue | Where-Object Status -eq "Running")

        $rol = if ($hostLocal -match "FILE|FCOR") { "FileServer" }
               elseif ($hasSQL) { "Base de Datos" }
               elseif ($hasIIS) { "Web IIS" }
               else { "Aplicativo" }

        # --- 2. CORE (Hardware y SO) ---
        $os  = Get-CimInstance Win32_OperatingSystem
        $cs  = Get-CimInstance Win32_ComputerSystem
        $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
        
        # Limpieza del nombre del Sistema Operativo
        $rawOS = [string]$os.Caption
        $cleanOS = if ($rawOS -match "(Windows Server (2008|2012|2016|2019|2022|2025)( R2)?)") {
            $matches[1]
        } else {
            $rawOS -replace "Microsoft ", ""
        }

        # Extracci�n de IP principal para el Core y Hardening
        $redesIP = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true }
        $ipCore = if ($redesIP.IPAddress) { ($redesIP.IPAddress | Where-Object { $_ -match '\.' } | Select-Object -First 1) } else { "" }

        # Deducci�n del Tipo de Equipo (F�sico o Virtual)
        $tipoEquipo = if ($cs.Model -match "Virtual|VMware|KVM|Xen|Bochs|Hyper-V") { "Virtual" } else { "F�sico" }

        # Verificaci�n de Reinicio Pendiente en el Registro
        $rebootPending = $false
        if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") { $rebootPending = $true }
        if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") { $rebootPending = $true }
        $pendFile = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "PendingFileRenameOperations" -ErrorAction SilentlyContinue
        if ($pendFile) { $rebootPending = $true }

        $uptimeDias = if ($os.LastBootUpTime) { [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalDays, 2) } else { 0 }
        $ramGB      = if ($cs.TotalPhysicalMemory) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 0) } else { 0 }
        $dominio    = if ($cs.Domain) { $cs.Domain } else { "WORKGROUP" }

        $coreData = [PSCustomObject]@{
            Hostname          = $hostLocal
            IP                = $ipCore
            TipoEquipo        = $tipoEquipo
            Ambiente          = $ambiente
            Rol               = $rol
            EstadoConexion    = "Online"
            Fabricante        = [string]$cs.Manufacturer
            Modelo            = [string]$cs.Model
            CPU_Modelo        = [string]$cpu.Name
            CPU               = [string]$cs.NumberOfLogicalProcessors
            RAM_GB            = $ramGB
            SistemaOperativo  = $cleanOS
            OS_Version        = [string]$os.Version
            OS_Build          = [string]$os.BuildNumber
            Dominio           = $dominio
            Uptime_Dias       = $uptimeDias
            ReinicioPendiente = if ($rebootPending) { "Si" } else { "No" }
        }

        # --- 3. HARDENING (Consultando RSOP para GPOs con CIS) ---
        $gpos = Get-CimInstance -Namespace root\rsop\computer -Class RSOP_GPO -ErrorAction SilentlyContinue
        $cisTemplate = ""
        
        if ($gpos) {
            $cisTemplate = ($gpos.Name | Where-Object { $_ -match "CIS" }) -join ", "
        }
        
        if ([string]::IsNullOrWhiteSpace($cisTemplate)) {
            $cisTemplate = "No detectada"
        }

        $hardeningData = [PSCustomObject]@{
            Hostname          = $hostLocal
            IP                = $ipCore
            PlantillaAplicada = $cisTemplate
        }

        # --- 4. DISCOS LOCALES ---
        $discos = Get-CimInstance Win32_LogicalDisk -Filter "DriveType = 3"
        $discosData = @()
        foreach ($disco in $discos) {
            $capacidadGB = if ($disco.Size) { [math]::Round($disco.Size / 1GB, 2) } else { 0 }
            $libreGB     = if ($disco.FreeSpace) { [math]::Round($disco.FreeSpace / 1GB, 2) } else { 0 }
            $porcentaje  = if ($capacidadGB -gt 0) { [math]::Round((($capacidadGB - $libreGB) / $capacidadGB) * 100, 2) } else { 0 }

            $etiqueta = $disco.VolumeName
            if ($disco.DeviceID -match "^C") {
                $etiqueta = "SistemaOperativo"
            }

            $discosData += [PSCustomObject]@{
                Hostname       = $hostLocal
                LetraUnidad    = $disco.DeviceID
                Etiqueta       = $etiqueta
                File_System    = $disco.FileSystem
                Capacidad_GB   = $capacidadGB
                EspacioLibre_GB= $libreGB
                PorcentajeUso  = $porcentaje
            }
        }

        # --- 5. RED (Interfaces activas con IP) ---
        $redes = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true }
        $redData = @()
        foreach ($red in $redes) {
            $ip = if ($red.IPAddress) { ($red.IPAddress | Where-Object { $_ -match '\.' } | Select-Object -First 1) } else { "" }
            $mascara = if ($red.IPSubnet) { ($red.IPSubnet | Where-Object { $_ -match '\.' } | Select-Object -First 1) } else { "" }
            $gw = if ($red.DefaultIPGateway) { ($red.DefaultIPGateway | Where-Object { $_ -match '\.' } | Select-Object -First 1) } else { "" }
            $dnsList = if ($red.DNSServerSearchOrder) { $red.DNSServerSearchOrder -join ", " } else { "" }

            $redData += [PSCustomObject]@{
                Hostname       = $hostLocal
                Adaptador      = $red.Description
                MAC_Address    = $red.MACAddress
                Direccion_IP   = $ip
                Mascara        = $mascara
                Gateway        = $gw
                DNS_Servidores = $dnsList
            }
        }

        [PSCustomObject]@{
            Hostname  = $hostLocal
            Core      = $coreData
            Hardening = $hardeningData
            Discos    = $discosData
            Red       = $redData
        }
    }
    catch {
        [PSCustomObject]@{
            Hostname  = $hostLocal
            Core      = $null
            Hardening = $null
            Discos    = @()
            Red       = @()
        }
    }
}

# ==========================================
# EJECUCI�N REMOTA (BLOQUES DE 50)
# ==========================================
$infoRemota = @()
$tamanioLote = 50

Write-Host "Iniciando escaneo de infraestructura por WinRM..." -ForegroundColor Cyan

for ($i = 0; $i -lt $servers.Count; $i += $tamanioLote) {
    $lote = $servers[$i..([math]::Min($i + $tamanioLote - 1, $servers.Count - 1))]
    $infoRemota += Invoke-Command -ComputerName $lote -ScriptBlock $scriptBlockRemoto -SessionOption $sessionOption -ThrottleLimit $tamanioLote -ErrorAction SilentlyContinue
}

$resultados = @(foreach ($item in $infoRemota) { $item })
$servidoresConRespuesta = @($resultados | Select-Object -ExpandProperty Hostname -Unique)

$listaCore = @()
$listaHardening = @()
$listaDiscos = @()
$listaRed = @()

foreach ($res in $resultados) {
    if ($res.Core) { $listaCore += $res.Core }
    if ($res.Hardening) { $listaHardening += $res.Hardening }
    if ($res.Discos) { $listaDiscos += $res.Discos }
    if ($res.Red) { $listaRed += $res.Red }
}

foreach ($srv in $servers) {
    if ($srv -notin $servidoresConRespuesta) {
        $hostOff = $srv.ToUpper()
        
        $ambienteOff = if ($hostOff -match "^(TD|RD|INVD|MS)") { "Desarrollo" }
                    elseif ($hostOff -match "^(RQ|INVQ|TQ)") { "QA" }
                    elseif ($hostOff -match "^(RX)") { "Tools" }
                    elseif ($hostOff -match "^(DR|VIR)") { "DRP" }
                    elseif ($hostOff -match "^(RP)") { "Produccion" }
                    else { "Producci�n" }
        
        $rolOff = if ($hostOff -match "FILE|FCOR") { "FileServer" }
                  elseif ($hostOff -match "SQL|DB|BD") { "Base de Datos" }
                  else { "Desconocido (Offline)" }

        $listaCore += [PSCustomObject]@{
            Hostname          = [string]$srv
            IP                = "-"
            TipoEquipo        = "-"
            Ambiente          = $ambienteOff
            Rol               = $rolOff
            EstadoConexion    = "Offline"
            Fabricante        = "-"
            Modelo            = "-"
            CPU_Modelo        = "-"
            CPU               = "-"
            RAM_GB            = 0
            SistemaOperativo  = "-"
            OS_Version        = "-"
            OS_Build          = "-"
            Dominio           = "-"
            Uptime_Dias       = 0
            ReinicioPendiente = "-"
        }
    }
}

# ==========================================
# FASE SQL: INSERCI�N (MODO HIST�RICO - SIN TRUNCATE)
# ==========================================
$connectionString = "Server=RXGSWSO01;Database=ServerWindows;User Id=sa;Password=N@7an2026#;"
$conn = New-Object System.Data.SqlClient.SqlConnection($connectionString)

try {
    $conn.Open()
    $transaction = $conn.BeginTransaction()
    $cmd = $conn.CreateCommand()
    $cmd.Transaction = $transaction

    Write-Host "Iniciando guardado de historia en SQL (sin borrar lo anterior)..." -ForegroundColor Yellow

    # Borramos primero SOLAMENTE los datos del d�a de HOY para evitar errores de llave primaria si el script se corre 2 veces el mismo d�a
    $cmd.CommandText = "DELETE FROM Servidores_Core WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM Servidores_Hardening WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM Servidores_Discos WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM Servidores_Red WHERE FechaConsulta = CAST(GETDATE() AS DATE);"
    [void]$cmd.ExecuteNonQuery()

    # 1. Insertar Core
    $cmd.CommandText = @"
        INSERT INTO Servidores_Core (Hostname, IP, TipoEquipo, Ambiente, Rol, EstadoConexion, Fabricante, Modelo, CPU_Modelo, CPU, RAM_GB, SistemaOperativo, OS_Version, OS_Build, Dominio, Uptime_Dias, ReinicioPendiente, FechaConsulta) 
        VALUES (@Hostname, @IP, @TipoEquipo, @Ambiente, @Rol, @EstadoConexion, @Fabricante, @Modelo, @CPU_Modelo, @CPU, @RAM_GB, @SistemaOperativo, @OS_Version, @OS_Build, @Dominio, @Uptime_Dias, @ReinicioPendiente, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaCore) {
        $cmd.Parameters.Clear()
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@IP", $item.IP)
        [void]$cmd.Parameters.AddWithValue("@TipoEquipo", $item.TipoEquipo)
        [void]$cmd.Parameters.AddWithValue("@Ambiente", $item.Ambiente)
        [void]$cmd.Parameters.AddWithValue("@Rol", $item.Rol)
        [void]$cmd.Parameters.AddWithValue("@EstadoConexion", $item.EstadoConexion)
        [void]$cmd.Parameters.AddWithValue("@Fabricante", $item.Fabricante)
        [void]$cmd.Parameters.AddWithValue("@Modelo", $item.Modelo)
        [void]$cmd.Parameters.AddWithValue("@CPU_Modelo", $item.CPU_Modelo)
        [void]$cmd.Parameters.AddWithValue("@CPU", $item.CPU)
        [void]$cmd.Parameters.AddWithValue("@RAM_GB", $item.RAM_GB)
        [void]$cmd.Parameters.AddWithValue("@SistemaOperativo", $item.SistemaOperativo)
        [void]$cmd.Parameters.AddWithValue("@OS_Version", $item.OS_Version)
        [void]$cmd.Parameters.AddWithValue("@OS_Build", $item.OS_Build)
        [void]$cmd.Parameters.AddWithValue("@Dominio", $item.Dominio)
        [void]$cmd.Parameters.AddWithValue("@Uptime_Dias", $item.Uptime_Dias)
        [void]$cmd.Parameters.AddWithValue("@ReinicioPendiente", $item.ReinicioPendiente)
        [void]$cmd.ExecuteNonQuery()
    }

    # 2. Insertar Hardening
    $cmd.CommandText = @"
        INSERT INTO Servidores_Hardening (Hostname, IP, PlantillaAplicada, FechaConsulta) 
        VALUES (@Hostname, @IP, @Plantilla, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaHardening) {
        $cmd.Parameters.Clear()
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@IP", $item.IP)
        [void]$cmd.Parameters.AddWithValue("@Plantilla", $item.PlantillaAplicada)
        [void]$cmd.ExecuteNonQuery()
    }

    # 3. Insertar Discos
    $cmd.CommandText = @"
        INSERT INTO Servidores_Discos (Hostname, LetraUnidad, Etiqueta, File_System, Capacidad_GB, EspacioLibre_GB, PorcentajeUso, FechaConsulta) 
        VALUES (@Hostname, @Letra, @Etiqueta, @FS, @Cap, @Libre, @Uso, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaDiscos) {
        $cmd.Parameters.Clear()
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@Letra", $item.LetraUnidad)
        [void]$cmd.Parameters.AddWithValue("@Etiqueta", $item.Etiqueta)
        [void]$cmd.Parameters.AddWithValue("@FS", $item.File_System)
        [void]$cmd.Parameters.AddWithValue("@Cap", $item.Capacidad_GB)
        [void]$cmd.Parameters.AddWithValue("@Libre", $item.EspacioLibre_GB)
        [void]$cmd.Parameters.AddWithValue("@Uso", $item.PorcentajeUso)
        [void]$cmd.ExecuteNonQuery()
    }

    # 4. Insertar Red
    $cmd.CommandText = @"
        INSERT INTO Servidores_Red (Hostname, Adaptador, MAC_Address, Direccion_IP, Mascara, Gateway, DNS_Servidores, FechaConsulta) 
        VALUES (@Hostname, @Adaptador, @MAC, @IP, @Mascara, @GW, @DNS, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaRed) {
        $cmd.Parameters.Clear()
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@Adaptador", $item.Adaptador)
        [void]$cmd.Parameters.AddWithValue("@MAC", $item.MAC_Address)
        [void]$cmd.Parameters.AddWithValue("@IP", $item.Direccion_IP)
        [void]$cmd.Parameters.AddWithValue("@Mascara", $item.Mascara)
        [void]$cmd.Parameters.AddWithValue("@GW", $item.Gateway)
        [void]$cmd.Parameters.AddWithValue("@DNS", $item.DNS_Servidores)
        [void]$cmd.ExecuteNonQuery()
    }

    $transaction.Commit()
    Write-Host "�M�dulo de Infraestructura completado! Datos del d�a $(Get-Date -Format 'dd-MM-yyyy') guardados exitosamente." -ForegroundColor Green
}
catch {
    if ($transaction) { $transaction.Rollback() }
    Write-Host "Error al guardar en SQL: $_" -ForegroundColor Red
}
finally {
    $conn.Close()
}
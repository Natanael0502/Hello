﻿$servers = Get-Content C:\ServersIT\serversFull.txt
foreach ($srv in $servers) {
    if (Test-WSMan $srv -ErrorAction SilentlyContinue) {
        "$srv - Conecta"
    } else {
        "$srv - No conecta"
    }
}
﻿# ==========================================
# PORTAL WINDOWS SERVERS - BLOQUE 4: SOFTWARE, SERVICIOS E IIS (HISTÓRICO)
# ==========================================
$serversFile = "C:\ServersIT\servers.txt" # Ajusta a la ruta real de tu archivo
if (-not (Test-Path $serversFile)) {
    Write-Host "Archivo servers.txt no encontrado." -ForegroundColor Red
    exit
}

[string[]]$servers = Get-Content $serversFile -ErrorAction Stop | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
$sessionOption = New-PSSessionOption -OpenTimeout 120000 -CancelTimeout 120000 -OperationTimeout 120000 

# ==========================================
# CEREBRO REMOTO (Extrae Parches, Software, Tareas, Servicios e IIS)
# ==========================================
$scriptBlockRemoto = {
    $ErrorActionPreference = "SilentlyContinue"
    $hostLocal = $env:COMPUTERNAME.ToUpper()

    try {
        # --- 1. PARCHES ---
        $parches = Get-HotFix | Select-Object HotFixID, Description, InstalledOn
        $parchesData = @()
        foreach ($p in $parches) {
            $fechaInst = if ($p.InstalledOn) { 
                if ($p.InstalledOn -is [datetime]) { $p.InstalledOn.ToString("yyyy-MM-dd HH:mm:ss") }
                else { $p.InstalledOn }
            } else { $null }

            $parchesData += [PSCustomObject]@{
                Hostname         = $hostLocal
                ParcheKB         = $p.HotFixID
                Descripcion      = $p.Description
                FechaInstalacion = $fechaInst
                Estado           = "Instalado"
            }
        }

        # --- 2. PROGRAMAS INSTALADOS (Desde el Registro) ---
        $swPaths = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
        )
        $programas = Get-ItemProperty $swPaths -ErrorAction SilentlyContinue | 
                     Where-Object { $_.DisplayName -and $_.DisplayName -notmatch "^KB\d+" } | 
                     Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | 
                     Sort-Object DisplayName -Unique
        
        $programasData = @()
        foreach ($prog in $programas) {
            $fechaProg = $null
            if ($prog.InstallDate -match '^(\d{4})(\d{2})(\d{2})$') { 
                $fechaProg = "$($matches[1])-$($matches[2])-$($matches[3])" 
            }

            $programasData += [PSCustomObject]@{
                Hostname         = $hostLocal
                NombrePrograma   = $prog.DisplayName
                Version          = $prog.DisplayVersion
                Editor           = $prog.Publisher
                FechaInstalacion = $fechaProg
            }
        }

        # --- 3. TAREAS PROGRAMADAS (Excluyendo las del sistema Microsoft) ---
        $tareasData = @()
        if (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue) {
            # Filtramos las tareas del sistema para no llenar la BD con 100+ tareas default
            $tareas = Get-ScheduledTask | Where-Object { $_.TaskPath -notmatch '^\\Microsoft' }
            foreach ($t in $tareas) {
                $info = $t | Get-ScheduledTaskInfo
                $tareasData += [PSCustomObject]@{
                    Hostname           = $hostLocal
                    NombreTarea        = $t.TaskName
                    Estado             = $t.State
                    SiguienteEjecucion = if ($info.NextRunTime) { $info.NextRunTime.ToString("yyyy-MM-dd HH:mm:ss") } else { $null }
                    UltimaEjecucion    = if ($info.LastRunTime) { $info.LastRunTime.ToString("yyyy-MM-dd HH:mm:ss") } else { $null }
                    UltimoResultado    = $info.LastTaskResult
                    UsuarioEjecucion   = $t.Principal.UserId
                }
            }
        }

        # --- 4. SERVICIOS ---
        $servicios = Get-CimInstance Win32_Service
        $serviciosData = @()
        foreach ($svc in $servicios) {
            $serviciosData += [PSCustomObject]@{
                Hostname       = $hostLocal
                NombreServicio = $svc.Name
                NombreMostrar  = $svc.DisplayName
                Estado         = $svc.State
                ModoInicio     = $svc.StartMode
                CuentaLogon    = $svc.StartName
            }
        }

        # Empaquetamos todo
        [PSCustomObject]@{
            Hostname  = $hostLocal
            Parches   = $parchesData
            Programas = $programasData
            Tareas    = $tareasData
            Servicios = $serviciosData
        }
    }
    catch {
        [PSCustomObject]@{
            Hostname  = $hostLocal
            Parches   = @()
            Programas = @()
            Tareas    = @()
            Servicios = @()
        }
    }
}

# ==========================================
# EJECUCIÓN REMOTA (Optimizado sin For manual)
# ==========================================
$tamanioLote = 20 # Mantenemos lote de 20 por el volumen de datos

Write-Host "Iniciando escaneo masivo de Software, Parches y Servicios por WinRM en $($servers.Count) servidores..." -ForegroundColor Cyan

# Invoke-Command maneja el loteo automáticamente con -ThrottleLimit, siendo mucho más rápido
$infoRemota = Invoke-Command -ComputerName $servers -ScriptBlock $scriptBlockRemoto -SessionOption $sessionOption -ThrottleLimit $tamanioLote -ErrorAction SilentlyContinue

$listaParches   = @()
$listaProgramas = @()
$listaTareas    = @()
$listaServicios = @()

foreach ($res in $infoRemota) {
    if ($res.Parches)   { $listaParches   += $res.Parches }
    if ($res.Programas) { $listaProgramas += $res.Programas }
    if ($res.Tareas)    { $listaTareas    += $res.Tareas }
    if ($res.Servicios) { $listaServicios += $res.Servicios }
}

# ==========================================
# FASE SQL: INSERCIÓN (MODO HISTÓRICO - SIN TRUNCATE)
# ==========================================
$connectionString = "Server=RXGSWSO01;Database=ServerWindows;User Id=sa;Password=N@7an2026#;"
$conn = New-Object System.Data.SqlClient.SqlConnection($connectionString)

try {
    $conn.Open()
    $transaction = $conn.BeginTransaction()
    $cmd = $conn.CreateCommand()
    $cmd.Transaction = $transaction
    
    # IMPORTANTE: Aumentamos el Timeout del comando SQL porque insertará miles de registros
    $cmd.CommandTimeout = 300 

    # 1. Borrar SÓLO los datos del día de HOY
    Write-Host "Limpiando datos del día de hoy para evitar duplicados..." -ForegroundColor Yellow
    $cmd.CommandText = "DELETE FROM Parches WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM ProgramasInstalados WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM TareasProgramadas WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM Servicios WHERE FechaConsulta = CAST(GETDATE() AS DATE);" +
                       "DELETE FROM Servidores_IIS_Sitios WHERE FechaConsulta = CAST(GETDATE() AS DATE);"
    [void]$cmd.ExecuteNonQuery()
    Write-Host "Limpieza completada. Escribiendo nueva información histórica..." -ForegroundColor Yellow

    # 2. Insertar Parches
    $cmd.CommandText = @"
        INSERT INTO Parches (Hostname, ParcheKB, Descripcion, FechaInstalacion, Estado, FechaConsulta) 
        VALUES (@Hostname, @ParcheKB, @Descripcion, @FechaInst, @Estado, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaParches) {
        $cmd.Parameters.Clear()
        
        $desc = if ([string]::IsNullOrWhiteSpace($item.Descripcion)) { [DBNull]::Value } else { $item.Descripcion }
        $fInst = if ([string]::IsNullOrWhiteSpace($item.FechaInstalacion)) { [DBNull]::Value } else { $item.FechaInstalacion }
        
        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@ParcheKB", $item.ParcheKB)
        [void]$cmd.Parameters.AddWithValue("@Descripcion", $desc)
        [void]$cmd.Parameters.AddWithValue("@FechaInst", $fInst)
        [void]$cmd.Parameters.AddWithValue("@Estado", $item.Estado)
        [void]$cmd.ExecuteNonQuery()
    }
    Write-Host "- Parches guardados."

    # 3. Insertar Programas
    $cmd.CommandText = @"
        INSERT INTO ProgramasInstalados (Hostname, NombrePrograma, Version, Editor, FechaInstalacion, FechaConsulta) 
        VALUES (@Hostname, @NombreProg, @Version, @Editor, @FechaInst, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaProgramas) {
        $cmd.Parameters.Clear()
        
        $ver = if ([string]::IsNullOrWhiteSpace($item.Version)) { [DBNull]::Value } else { $item.Version }
        $edi = if ([string]::IsNullOrWhiteSpace($item.Editor)) { [DBNull]::Value } else { $item.Editor }
        $fInstP = if ([string]::IsNullOrWhiteSpace($item.FechaInstalacion)) { [DBNull]::Value } else { $item.FechaInstalacion }

        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@NombreProg", $item.NombrePrograma)
        [void]$cmd.Parameters.AddWithValue("@Version", $ver)
        [void]$cmd.Parameters.AddWithValue("@Editor", $edi)
        [void]$cmd.Parameters.AddWithValue("@FechaInst", $fInstP)
        [void]$cmd.ExecuteNonQuery()
    }
    Write-Host "- Programas guardados."

    # 4. Insertar Tareas Programadas
    $cmd.CommandText = @"
        INSERT INTO TareasProgramadas (Hostname, NombreTarea, Estado, SiguienteEjecucion, UltimaEjecucion, UltimoResultado, UsuarioEjecucion, FechaConsulta) 
        VALUES (@Hostname, @NombreTarea, @Estado, @SigEjecucion, @UltEjecucion, @UltRes, @Usuario, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaTareas) {
        $cmd.Parameters.Clear()
        
        $est = if ([string]::IsNullOrWhiteSpace($item.Estado)) { [DBNull]::Value } else { $item.Estado }
        $sigEj = if ([string]::IsNullOrWhiteSpace($item.SiguienteEjecucion)) { [DBNull]::Value } else { $item.SiguienteEjecucion }
        $ultEj = if ([string]::IsNullOrWhiteSpace($item.UltimaEjecucion)) { [DBNull]::Value } else { $item.UltimaEjecucion }
        $ultRes = if ($null -ne $item.UltimoResultado -and $item.UltimoResultado -ne "") { $item.UltimoResultado.ToString() } else { [DBNull]::Value }
        $usr = if ([string]::IsNullOrWhiteSpace($item.UsuarioEjecucion)) { [DBNull]::Value } else { $item.UsuarioEjecucion }

        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@NombreTarea", $item.NombreTarea)
        [void]$cmd.Parameters.AddWithValue("@Estado", $est)
        [void]$cmd.Parameters.AddWithValue("@SigEjecucion", $sigEj)
        [void]$cmd.Parameters.AddWithValue("@UltEjecucion", $ultEj)
        [void]$cmd.Parameters.AddWithValue("@UltRes", $ultRes)
        [void]$cmd.Parameters.AddWithValue("@Usuario", $usr)
        [void]$cmd.ExecuteNonQuery()
    }
    Write-Host "- Tareas Programadas guardadas."

    # 5. Insertar Servicios
    $cmd.CommandText = @"
        INSERT INTO Servicios (Hostname, NombreServicio, NombreMostrar, Estado, ModoInicio, CuentaLogon, FechaConsulta) 
        VALUES (@Hostname, @NombreSvc, @NombreMostrar, @Estado, @ModoInicio, @CuentaLogon, CAST(GETDATE() AS DATE))
"@
    foreach ($item in $listaServicios) {
        $cmd.Parameters.Clear()
        
        $nomM = if ([string]::IsNullOrWhiteSpace($item.NombreMostrar)) { [DBNull]::Value } else { $item.NombreMostrar }
        $modI = if ([string]::IsNullOrWhiteSpace($item.ModoInicio)) { [DBNull]::Value } else { $item.ModoInicio }
        $ctaL = if ([string]::IsNullOrWhiteSpace($item.CuentaLogon)) { [DBNull]::Value } else { $item.CuentaLogon }

        [void]$cmd.Parameters.AddWithValue("@Hostname", $item.Hostname)
        [void]$cmd.Parameters.AddWithValue("@NombreSvc", $item.NombreServicio)
        [void]$cmd.Parameters.AddWithValue("@NombreMostrar", $nomM)
        [void]$cmd.Parameters.AddWithValue("@Estado", $item.Estado)
        [void]$cmd.Parameters.AddWithValue("@ModoInicio", $modI)
        [void]$cmd.Parameters.AddWithValue("@CuentaLogon", $ctaL)
        [void]$cmd.ExecuteNonQuery()
    }
    Write-Host "- Servicios guardados."

    $transaction.Commit()
    Write-Host "¡Bloque 4 Completado Exitosamente! Datos del día $(Get-Date -Format 'dd-MM-yyyy') guardados." -ForegroundColor Green
}
catch {
    if ($transaction) { $transaction.Rollback() }
    Write-Host "Error al guardar en SQL: $_" -ForegroundColor Red
}
finally {
    if ($conn.State -eq 'Open') {
        $conn.Close()
    }
}